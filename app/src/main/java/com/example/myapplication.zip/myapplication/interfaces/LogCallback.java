package com.example.myapplication.interfaces;

public interface LogCallback {
    void onSuccess();
    void onFailure(Exception e);
}
