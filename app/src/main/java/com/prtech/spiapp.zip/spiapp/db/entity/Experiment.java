package com.prtech.spiapp.db.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.prtech.spiapp.db.converters.ExperimentCommandsConverter;

import java.util.List;

@Entity(tableName="experiments")
public class Experiment {
    @PrimaryKey(autoGenerate = true)
    public Long id;

    @ColumnInfo(name="title")
    public String title;

    @ColumnInfo(name="commands")
    @TypeConverters(ExperimentCommandsConverter.class)
    public List<String> commands;

    @ColumnInfo(name="set_id")
    public Integer experimentSet;

    @ColumnInfo(name="number_of_trials")
    public Integer numberOfTrials;

    @ColumnInfo(name="command")
    public Float command;

    @ColumnInfo(name="pre_run")
    public Float preRun;

    @ColumnInfo(name="post_run")
    public Float postRun;

    @ColumnInfo(name="rest")
    public Float rest;

    @ColumnInfo(name="rest_random")
    public Float restRandom;

    public Experiment(String title, List<String> commands, Integer experimentSet, Integer numberOfTrials, Float command, Float preRun, Float postRun, Float rest, Float restRandom) {
        this.title = title;
        this.experimentSet = experimentSet;
        this.command = command;
        this.commands = commands;
        this.numberOfTrials = numberOfTrials;
        this.preRun = preRun;
        this.postRun = postRun;
        this.rest = rest;
        this.restRandom = restRandom;
    }

    public void copyFrom(Experiment other) {
        this.id = other.getId();
        this.title = other.getTitle();
        this.experimentSet = other.getExperimentSet();
        this.commands = other.getCommands();
        this.numberOfTrials = other.getNumberOfTrials();
        this.command = other.getCommand();
        this.preRun = other.getPreRun();
        this.postRun = other.getPostRun();
        this.rest = other.getRest();
        this.restRandom = other.getRestRandom();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getExperimentSet() {
        return experimentSet;
    }

    public void setExperimentSet(Integer experimentSet) {
        this.experimentSet = experimentSet;
    }

    public List<String> getCommands() {
        return commands;
    }

    public void setCommands(List<String> commands) {
        this.commands = commands;
    }

    public Integer getNumberOfTrials() {
        return numberOfTrials;
    }

    public void setNumberOfTrials(Integer numberOfTrials) {
        this.numberOfTrials = numberOfTrials;
    }

    public Float getCommand() {
        return command;
    }

    public void setCommand(Float command) {
        this.command = command;
    }

    public Float getPreRun() {
        return preRun;
    }

    public void setPreRun(Float preRun) {
        this.preRun = preRun;
    }

    public Float getPostRun() {
        return postRun;
    }

    public void setPostRun(Float postRun) {
        this.postRun = postRun;
    }

    public Float getRest() {
        return rest;
    }

    public void setRest(Float rest) {
        this.rest = rest;
    }

    public Float getRestRandom() {
        return restRandom;
    }

    public void setRestRandom(Float restRandom) {
        this.restRandom = restRandom;
    }
}
